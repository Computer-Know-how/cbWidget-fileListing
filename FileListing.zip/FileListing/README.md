File Listing Widget
=================

Author
-----------------
Computer Know How/Seth Engen

Description
-----------------
Sweet ContentBox Widget for listing out files in a specified directory.

Installation
-----------------
Install from the ContentBox Admin or drop the CFC in your ContentBox widgets folder and reload.

Usage
-----------------
Call the widget and place it where you want to show your file list.  You can use the built in Widget insert for CKEditor in ContentBox for the easy way to add the file list to your page or you can use the CB Helper method widget():  ```#cb.widget('FileListing',{folder='/',filter="*.pdf"})#```

Change Log
-----------------
* Version 1.1 - Security Updates, Show Icons
* Version 1.0 - Initial Release
